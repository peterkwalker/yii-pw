<?php

use yii\helpers\Html;
use yii\grid\GridView;
use fedemotta\datatables\DataTables;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SubscribersSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Subscribers';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="subscribers-index">

    <h1><?= Html::encode($this->title) ?></h1>


   <a href="view?id=<?php echo $dataProvider->models[0]->userid ?>"> 
   <?php // single record
     echo $dataProvider->models[0]->username ?> </a>


<?php // loop records 
foreach ($dataProvider->models as $model) {
   echo $model->username .'<br>';
}
?>

<table width="100%" class="table table-striped table-hover">
    <thead>
        <tr>
            <th>Name</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php // loop records 
foreach ($dataProvider->models as $model) { ?>
        <tr>
            <td><?php echo $model->username ?></td>
            <td></td>
        </tr>
    <?php } ?>
    </tbody>
</table>
    

    <p style="margin-bottom:30px;">
        <?= Html::a('Create Subscriber', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= DataTables::widget([

'clientOptions' => [
    "lengthMenu"=> [[20,-1], [20,Yii::t('app',"All")]],
    "info"=>true,
    "responsive"=>true, 
    "aaSorting"=> [[ 0, "asc" ]],
    "columnDefs"=> [
    [ "width"=> "100px", "targets"=> 3 ],
    [ "width"=> "100px", "targets"=> 1 ],
    [ "className" => "text-right", "targets"=> [3] ],
    [ "orderable" => false, "targets"=> [3] ],
  ]
  ],
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
         //  ['class' => 'yii\grid\SerialColumn'],
        // 'userid',
            'username',
            'groupid',
            'town',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>


