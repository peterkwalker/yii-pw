<?php
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use app\models\Groups;


/* @var $this yii\web\View */
/* @var $model app\models\Subscribers */

$this->title = 'Create Subscribers';
$this->params['breadcrumbs'][] = ['label' => 'Subscribers', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="subscribers-create">

   <?php $registerForm = ActiveForm::begin([
        'id' => 'register-form',
        'layout' => 'horizontal',
        'fieldConfig' => [
            'template' => "{label}\n<div class=\"col-lg-3\">{input}</div>\n<div class=\"col-lg-7\">{error}</div>",
            'labelOptions' => ['class' => 'col-lg-2 control-label'],
        ],
    ]); ?>


<?= $registerForm->errorSummary($model)?>
<?= $registerForm->field($model, 'username')->textInput(['autofocus' => true]) ?>
<?php
    echo $registerForm->field($model, 'groupid')->dropDownList(ArrayHelper::map(Groups::find()->all(),'groupid','groupname'),['prompt'=>'Select Group']);
?>
<?= $registerForm->field($model, 'town')->textInput() ?>

       <div class="form-group">
            <div class="col-lg-offset-1 col-lg-11">
                <?= Html::submitButton('Save', ['class' => 'btn btn-primary', 'name' => 'login-button']) ?>
            </div>
        </div>

    <?php ActiveForm::end(); ?>

</div>



 
