<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "subscribers".
 *
 * @property int $userid
 * @property string $username
 * @property int $groupid
 * @property string $town
 *
 * @property Groups $group
 */
class Subscribers extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'subscribers';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['username', 'groupid', 'town'], 'required'],
            [['groupid'], 'integer'],
            [['username'], 'string', 'max' => 50],
             [['town'], 'string', 'max' => 50],
            [['username'], 'unique'],
            [['groupid'], 'exist', 'skipOnError' => true, 'targetClass' => Groups::className(), 'targetAttribute' => ['groupid' => 'groupid']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'userid' => 'Userid',
            'username' => 'Username',
            'groupid' => 'Groupid',
            'town' => 'Town',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroup()
    {
        return $this->hasOne(Groups::className(), ['groupid' => 'groupid']);
    }
}
