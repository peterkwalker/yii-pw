<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "groups".
 *
 * @property int $groupid
 * @property string $groupname
 *
 * @property Subscribers[] $subscribers
 */
class Groups extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'groups';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['groupname'], 'required'],
            [['groupname'], 'string', 'max' => 40],
            [['groupname'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'groupid' => 'Groupid',
            'groupname' => 'Groupname',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSubscribers()
    {
        return $this->hasMany(Subscribers::className(), ['groupid' => 'groupid']);
    }
}
